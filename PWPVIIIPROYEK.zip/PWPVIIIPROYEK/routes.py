from flask import Flask, render_template, request, redirect, session, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User

def init_routes(app):
    @app.route('/')
    def home():
        return redirect(url_for('login'))

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            username = request.form['username']
            role = request.form['role']
            email = request.form['email']
            password = request.form['password']
            hashed_password = generate_password_hash(password, method='sha256')
            new_user = User(username=username, role=role, email=email, password_hash=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! You can now login.', 'success')
            return redirect(url_for('login'))
        return render_template('register.html')

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            email = request.form['email']
            password = request.form['password']
            user = User.query.filter_by(email=email).first()
            if user and check_password_hash(user.password_hash, password):
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = user.role
                flash('Login successful!', 'success')
                return redirect(url_for('dashboard'))
            flash('Invalid credentials.', 'danger')
        return render_template('login.html')

    @app.route('/dashboard')
    def dashboard():
        if 'user_id' not in session:
            flash('Please login to access the dashboard.', 'warning')
            return redirect(url_for('login'))
        users = User.query.all()
        return render_template('dashboard.html', users=users)

    @app.route('/add', methods=['GET', 'POST'])
    def add_user():
        if 'user_id' not in session:
            flash('Please login to access this page.', 'warning')
            return redirect(url_for('login'))
        if request.method == 'POST':
            username = request.form['username']
            role = request.form['role']
            email = request.form['email']
            password = request.form['password']
            hashed_password = generate_password_hash(password, method='sha256')
            new_user = User(username=username, role=role, email=email, password_hash=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            flash('User added successfully!', 'success')
            return redirect(url_for('dashboard'))
        return render_template('add_user.html')

    @app.route('/edit/<int:id>', methods=['GET', 'POST'])
    def edit_user(id):
        if 'user_id' not in session:
            flash('Please login to access this page.', 'warning')
            return redirect(url_for('login'))
        user = User.query.get_or_404(id)
        if request.method == 'POST':
            user.username = request.form['username']
            user.role = request.form['role']
            user.email = request.form['email']
            if request.form['password']:
                user.password_hash = generate_password_hash(request.form['password'], method='sha256')
            db.session.commit()
            flash('User updated successfully!', 'success')
            return redirect(url_for('dashboard'))
        return render_template('edit_user.html', user=user)

    @app.route('/delete/<int:id>')
    def delete_user(id):
        if 'user_id' not in session:
            flash('Please login to access this page.', 'warning')
            return redirect(url_for('login'))
        user = User.query.get_or_404(id)
        db.session.delete(user)
        db.session.commit()
        flash('User deleted successfully!', 'success')
        return redirect(url_for('dashboard'))

    @app.route('/logout')
    def logout():
        session.clear()
        flash('You have been logged out.', 'info')
        return redirect(url_for('login'))
